class CarModel {
  constructor(plate, make, model, year, test, license, vin) {
    this.plate = plate;
    this.make = make;
    this.model = model;
    this.year = year;
    this.test = test;
    this.license = license;
    this.vin = vin;
  }
}
export default CarModel;