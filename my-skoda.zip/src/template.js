// import './HomePage.css';
// import React from 'react';

// class HomePage extends React.Component {
//   constructor(props) {
//     super(props);
//   }
//   render() {
//     return(
//         <div></div>
//     )
//   }
// }
// export default HomePage;